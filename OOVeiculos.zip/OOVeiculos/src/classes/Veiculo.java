/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author aluno
 */
public abstract class Veiculo implements acoes{
    private boolean ligado;
    private String dono;
    private int ano;
    private String cor;
    private int capTanque;
    private int tanqueAtual;
    private float precoComb;
    private int qntdPneu;
   
    

    public boolean isLigado() {
        return ligado;
    }

    public void setLigado(boolean ligado) {
        this.ligado = ligado;
    }
    
    
    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
    
    public int getCapTanque() {
        return capTanque;
    }

    public void setCapTanque(int capTanque) {
        this.capTanque = capTanque;
    }
    
    public int getTanqueAtual() {
        return tanqueAtual;
    }

    public void setTanqueAtual(int tanque) {
        this.tanqueAtual = tanque;
    }


    public float getPrecoComb() {
        return precoComb;
    }

    public void setPrecoComb(float precoComb) {
        this.precoComb = precoComb;
    }

    public int getQntdPneu() {
        return qntdPneu;
    }

    public void setQntdPneu(int qntdPneu) {
        this.qntdPneu = qntdPneu;
    }
    
    
        
}
