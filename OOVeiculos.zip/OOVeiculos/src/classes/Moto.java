/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author aluno
 */
public class Moto extends Veiculo {
    private int cilindradas;
    
    
    public Moto(String dono, int ano, String cor, int cilindradas){
        this.setDono(dono);
        this.setAno(ano);
        this.setCor(cor);
        this.setCilindradas(cilindradas);
        this.setLigado(false);
        this.setTanqueAtual(5);
        this.setCapTanque(10);
        this.setPrecoComb(6.00f);
        this.setQntdPneu(10);
        
    }

    public int getCilindradas() {
        return cilindradas;
    }

    public void setCilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }

    @Override
    public void ligar() {
        
        if(this.isLigado() == false){
            if(this.getTanqueAtual() < 1){
                System.out.println("Não há combustivel para ligar!");
            }else{
                System.out.println("Ligando a Moto... ");
                this.setTanqueAtual(this.getTanqueAtual() - 1);
                this.setLigado(true);
            }
        }else{
            System.out.println("A Moto já está ligada!");
        }
        
        
    }

    @Override
    public void desligar() {
        
        if(this.isLigado() == true){
            System.out.println("Desligando a Moto...");
            this.setLigado(false);
        }else{
            System.out.println("A Moto já está desligado!");
        }
        
        
    }

    @Override
    public void abastecer() {
        
        if(this.getTanqueAtual()< this.getCapTanque()){
            System.out.println("Abastecendo...");
            int preco = this.getCapTanque() - this.getTanqueAtual(); 
            this.setTanqueAtual(this.getCapTanque()) ;
            System.out.println("O preço a se pagar é: R$" + (preco * this.getPrecoComb() ));
            
        }else{
            System.out.println("O tanque já está cheio!");
        }
        
        
    }


    @Override
    public void acelerar() {
        
        if(this.isLigado()== true){
            if(this.getTanqueAtual() <= 4){
                System.out.println("Impossivel acelerar. A moto está sem combustível!");
            
            }else{
                System.out.println("VRUUUUUUUM...");
                this.setTanqueAtual(this.getTanqueAtual() - 5);
            }
        }else{
            System.out.println("Impossivel acelerar com a moto desligada!");
        }
        
        
    }

    
}
