/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author aluno
 */



public class Caminhao extends Veiculo {
    private int qntdCarroceria;
    
    
    public Caminhao(String dono, int ano, String cor){
        this.setDono(dono);
        this.setAno(ano);
        this.setCor(cor);
        this.setLigado(false);
        this.setTanqueAtual(15);
        this.setCapTanque(30);
        this.setPrecoComb(6.00f);
        this.setQntdCarroceria(0);
        this.setQntdPneu(6);
        
    }

    public int getQntdCarroceria() {
        return qntdCarroceria;
    }

    public void setQntdCarroceria(int qntdCarroceria) {
        this.qntdCarroceria = qntdCarroceria;
    }
    
    
    

    @Override
    public void ligar() {
        if(this.isLigado() == false){
            if(this.getTanqueAtual() < 1){
                System.out.println("Não há combustivel para ligar!");
            }else{
                System.out.println("Ligando o Caminhão... ");
                this.setTanqueAtual(this.getTanqueAtual() - 1);
                this.setLigado(true);
            }
        }else{
            System.out.println("O Caminhão já está ligado!");
        }
        
    }

    @Override
    public void desligar() {
        
        if(this.isLigado() == true){
            System.out.println("Desligando o Caminhão...");
            this.setLigado(false);
        }else{
            System.out.println("O Caminhão já está desligado!");
        }

    }

    @Override
    public void abastecer() {
        if(this.getTanqueAtual()< this.getCapTanque()){
            System.out.println("Abastecendo...");
            int preco = this.getCapTanque() - this.getTanqueAtual(); 
            this.setTanqueAtual(this.getCapTanque()) ;
            System.out.println("O preço a se pagar é: R$" + (preco * this.getPrecoComb() ));
            
        }else{
            System.out.println("O tanque já está cheio!");
        }
    }


    @Override
    public void acelerar() {
        
        if(this.isLigado()== true){
            if(this.getTanqueAtual() <= 4){
                System.out.println("Impossivel acelerar. O Carro está sem combustível!");
            
            }else{
                System.out.println("VRUUUUUUUM...");
                this.setTanqueAtual(this.getTanqueAtual() - 5);
            }
        }else{
            System.out.println("Impossivel acelerar com o carro dsligado!");
        }
        
    }



    
    
    
}